# Stephanie Potter — Portfolio (Static Site)

Build a plain HTML/CSS/JS portfolio that meets the assignment requirements exactly and can be pushed to a GitHub repo and served from GitHub Pages with zero build step.

## Files (all in `public/` so they're served as-is)

- `public/index.html` — Home
- `public/about.html` — About
- `public/projects.html` — Projects
- `public/contact.html` — Contact (bonus, referenced in nav)
- `public/styles.css` — Shared dark modern stylesheet
- `public/script.js` — Small JS (mobile nav toggle, current year, active link highlight)
- `public/README.md` — Deployment instructions for GitHub Pages

All pages share the same top navigation bar linking Home / About / Projects / Contact, plus a footer with GitHub link.

## Design

Dark & modern:
- Background near-black, off-white text, single bright accent (electric blue/violet).
- Large display headings, generous spacing, subtle card borders, hover accents.
- System font stack (fast, no external deps) with tasteful weight contrast.
- Fully responsive; mobile nav collapses to a menu button.
- Semantic HTML, alt text, proper `<title>` and meta description per page.

## Page content

**Home (`index.html`)**
- Hero: "Stephanie Potter — Marketing Strategist & Growth Partner"
- Short tagline, primary CTA to Projects, secondary to Contact
- Highlights strip: Marketing Strategy • SEO/GEO • Web Development • Social • Paid Media

**About (`about.html`)**
- Full bio from the answers (2016 marketing director → agency → joining Jayme's team → mission)
- Skills grid: Marketing Strategy & Planning, SEO/GEO, Web Development, Social Media Marketing, Paid Media
- Experience timeline (Marketing Director 2016+, Agency roles, Current partnership)
- Education section (placeholder text noting user can update)

**Projects (`projects.html`)**
- Card grid with the three live sites:
  - American Marketing Pros — https://theamericanmarketingpros.com/
  - American Pros — https://americanpros.com/
  - AHP of AZ — https://ahpofaz.com/
- Each card: title, short description of the work (marketing/web), "Visit site" link.
- Link to GitHub profile: https://github.com/potterstep

**Contact (`contact.html`)**
- GitHub link, prompt to reach out, and a mailto placeholder the user can fill in.
- Simple non-functional contact form (HTML only) noting it's a static demo.

## GitHub Pages deployment (in README)

1. Create a new GitHub repo.
2. Copy the contents of `public/` into the repo root (so `index.html` is at the root).
3. Push to `main`.
4. Repo → Settings → Pages → Source: `main` branch, `/ (root)` folder → Save.
5. Site goes live at `https://potterstep.github.io/<repo>/`.

## Notes / assumptions

- Using the browser-safe placeholder pages inside `public/` means they're served directly by the dev preview at `/index.html`, `/about.html`, etc., and can be lifted 1:1 into a GitHub repo — no build tooling required.
- The existing TanStack app remains untouched; the static files are additive.
- Education section uses placeholder text since none was provided — easy for the user to edit.
- No YouTube embed included (none provided); README notes where to add one.
