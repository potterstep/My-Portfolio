import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "../components/SiteLayout";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Stephanie Potter" },
      {
        name: "description",
        content:
          "About Stephanie Potter — background, skills, and experience across marketing strategy, SEO/GEO, web, social, and paid media.",
      },
      { property: "og:title", content: "About — Stephanie Potter" },
      {
        property: "og:description",
        content: "Background, skills, and experience across marketing strategy and web.",
      },
    ],
  }),
  component: About,
});

function About() {
  return (
    <SiteLayout>
      <section className="container">
        <span className="eyebrow">About</span>
        <h2>Hi, I'm Stephanie.</h2>
        <p className="section-sub" style={{ maxWidth: 720 }}>
          Stephanie started as a marketing director for a home service company of 150
          staff members in 2016. After years of service she made the move to help more
          contractors from an agency perspective.
        </p>
        <p style={{ maxWidth: 720, color: "var(--muted)" }}>
          Throughout her journey in agencies she realized her passion was to be an
          integral part of a home service company where she joined Jayme's team. After
          working together, and collaborating on marketing strategy, we recognized that
          our peers were in need of someone who cares as much about their business as
          we do about ours.
        </p>
        <p style={{ maxWidth: 720, color: "var(--muted)" }}>
          Her mission: to educate clients on standard best practices, build long-lasting
          marketing strategies, and partner with businesses for real growth.
        </p>
      </section>

      <section className="container">
        <h2>Skills</h2>
        <p className="section-sub">The toolkit I bring to every partnership.</p>
        <div className="grid">
          <div className="card">
            <h3>Marketing Strategy & Planning</h3>
            <p>Long-term roadmaps aligned to business goals, not vanity metrics.</p>
          </div>
          <div className="card">
            <h3>SEO / GEO</h3>
            <p>Local and generative engine optimization that earns qualified traffic.</p>
          </div>
          <div className="card">
            <h3>Web Development</h3>
            <p>Fast, conversion-focused websites built to grow with the business.</p>
          </div>
          <div className="card">
            <h3>Social Media Marketing</h3>
            <p>Content and community that supports trust and pipeline.</p>
          </div>
          <div className="card">
            <h3>Paid Media</h3>
            <p>Google, Meta, and beyond — measured, tuned, and profitable.</p>
          </div>
        </div>
      </section>

      <section className="container">
        <h2>Experience</h2>
        <p className="section-sub">A quick tour of the work.</p>
        <ul className="timeline">
          <li className="item">
            <h3>Marketing Partner — American Marketing Pros</h3>
            <div className="meta">Current</div>
            <p>
              Partnering with home service companies on end-to-end marketing strategy
              and execution.
            </p>
          </li>
          <li className="item">
            <h3>Agency Marketing Roles</h3>
            <div className="meta">Multiple years</div>
            <p>
              Led strategy and execution for contractors and service businesses across
              the country.
            </p>
          </li>
          <li className="item">
            <h3>Marketing Director — Home Service Company</h3>
            <div className="meta">2016 — In-house</div>
            <p>Built and led marketing for a 150-person home service company from the inside.</p>
          </li>
        </ul>
      </section>

      <section className="container">
        <h2>Education</h2>
        <p className="section-sub">Continuous learning across marketing, analytics, and web.</p>
        <div className="card" style={{ maxWidth: 520 }}>
          <h3>Ongoing Professional Development</h3>
          <p>
            Coursework and certifications in digital marketing, SEO, and web development.
            (Update this section with specific schools/certifications.)
          </p>
        </div>
      </section>
    </SiteLayout>
  );
}