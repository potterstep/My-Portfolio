import { createFileRoute } from "@tanstack/react-router";
import { type FormEvent } from "react";
import { SiteLayout } from "../components/SiteLayout";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Stephanie Potter" },
      {
        name: "description",
        content:
          "Get in touch with Stephanie Potter about marketing strategy, SEO, web, or growth partnerships.",
      },
      { property: "og:title", content: "Contact — Stephanie Potter" },
      {
        property: "og:description",
        content: "Reach out about marketing strategy, SEO, web, or growth partnerships.",
      },
    ],
  }),
  component: Contact,
});

function Contact() {
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    alert(
      "This is a static demo form. Wire it up to a real form service to receive messages.",
    );
  };

  return (
    <SiteLayout>
      <section className="container">
        <span className="eyebrow">Contact</span>
        <h2>Let's talk growth.</h2>
        <p className="section-sub" style={{ maxWidth: 640 }}>
          Whether it's a marketing audit, a website rebuild, or a long-term
          partnership — reach out and we'll figure out the best next step for your
          business.
        </p>

        <p>
          GitHub:{" "}
          <a href="https://github.com/potterstep" target="_blank" rel="noopener noreferrer">
            github.com/potterstep
          </a>
          <br />
          Email: <a href="mailto:hello@example.com">hello@example.com</a>{" "}
          <span style={{ color: "var(--muted)" }}>(update with your address)</span>
        </p>

        <form className="form" onSubmit={onSubmit}>
          <div>
            <label htmlFor="name">Name</label>
            <input id="name" name="name" type="text" required />
          </div>
          <div>
            <label htmlFor="email">Email</label>
            <input id="email" name="email" type="email" required />
          </div>
          <div>
            <label htmlFor="message">Message</label>
            <textarea id="message" name="message" rows={5} required />
          </div>
          <button className="btn btn-primary" type="submit">
            Send
          </button>
          <p className="note">
            This form is a static demo. Hook it up to a service like Formspree or
            Netlify Forms to receive submissions.
          </p>
        </form>
      </section>
    </SiteLayout>
  );
}