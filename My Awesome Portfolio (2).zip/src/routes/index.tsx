import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteLayout } from "../components/SiteLayout";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <SiteLayout>
      <section className="hero container">
        <span className="eyebrow">Marketing • Strategy • Growth</span>
        <h1>
          Building marketing that actually{" "}
          <span className="accent">moves the needle</span> for home service businesses.
        </h1>
        <p className="lead">
          I'm Stephanie Potter — a marketing strategist who partners with home service
          companies to grow through smarter SEO/GEO, thoughtful web development, and
          paid and organic media that pays for itself.
        </p>
        <div className="btn-row">
          <Link className="btn btn-primary" to="/projects">
            View Projects
          </Link>
          <Link className="btn btn-ghost" to="/contact">
            Get in Touch
          </Link>
        </div>
        <div className="strip">
          <span className="chip">Marketing Strategy</span>
          <span className="chip">SEO / GEO</span>
          <span className="chip">Web Development</span>
          <span className="chip">Social Media</span>
          <span className="chip">Paid Media</span>
        </div>
      </section>
    </SiteLayout>
  );
}
