import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "../components/SiteLayout";

export const Route = createFileRoute("/projects")({
  head: () => ({
    meta: [
      { title: "Projects — Stephanie Potter" },
      {
        name: "description",
        content: "Selected marketing and web development projects by Stephanie Potter.",
      },
      { property: "og:title", content: "Projects — Stephanie Potter" },
      {
        property: "og:description",
        content: "Selected marketing and web development projects.",
      },
    ],
  }),
  component: Projects,
});

const projects = [
  {
    title: "American Marketing Pros",
    href: "https://theamericanmarketingpros.com/",
    desc: "Full-service marketing agency site — strategy, SEO/GEO, web, and paid media for home service contractors.",
  },
  {
    title: "American Pros",
    href: "https://americanpros.com/",
    desc: "Brand and web presence for a home service operator — built for lead capture and local trust.",
  },
  {
    title: "AHP of AZ",
    href: "https://ahpofaz.com/",
    desc: "Arizona home service site with a focus on local SEO and clear service pathways for customers.",
  },
];

function Projects() {
  return (
    <SiteLayout>
      <section className="container">
        <span className="eyebrow">Projects</span>
        <h2>Selected Work</h2>
        <p className="section-sub">
          A few live sites and marketing programs I've helped build and grow.
        </p>

        <div className="grid">
          {projects.map((p) => (
            <article className="card" key={p.href}>
              <h3>{p.title}</h3>
              <p>{p.desc}</p>
              <a className="link" href={p.href} target="_blank" rel="noopener noreferrer">
                Visit site →
              </a>
            </article>
          ))}
        </div>

        <p style={{ marginTop: 32 }}>
          More code and experiments live on my GitHub:{" "}
          <a href="https://github.com/potterstep" target="_blank" rel="noopener noreferrer">
            github.com/potterstep
          </a>
        </p>
      </section>
    </SiteLayout>
  );
}