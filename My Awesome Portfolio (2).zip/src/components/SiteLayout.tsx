import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

const navItems = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/projects", label: "Projects" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteLayout({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [year, setYear] = useState<number | string>("");

  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  return (
    <>
      <header className="site-nav">
        <div className="container nav-inner">
          <Link className="brand" to="/">
            Stephanie<span>.</span>Potter
          </Link>
          <button
            className="nav-toggle"
            aria-label="Toggle menu"
            onClick={() => setOpen((v) => !v)}
          >
            Menu
          </button>
          <ul className={`nav-links${open ? " open" : ""}`}>
            {navItems.map((n) => (
              <li key={n.to}>
                <Link
                  to={n.to}
                  className={pathname === n.to ? "active" : ""}
                  onClick={() => setOpen(false)}
                >
                  {n.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </header>

      <main>{children}</main>

      <footer>
        <div className="container footer-inner">
          <div>&copy; {year} Stephanie Potter</div>
          <div>
            <a href="https://github.com/potterstep" target="_blank" rel="noopener noreferrer">
              github.com/potterstep
            </a>
          </div>
        </div>
      </footer>
    </>
  );
}